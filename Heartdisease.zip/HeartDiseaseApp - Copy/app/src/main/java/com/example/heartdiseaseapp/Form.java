package com.example.heartdiseaseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.util.Log;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.SeekBar;

public class Form extends AppCompatActivity {

    //private static String LOG_TAG = "UIElementsPracticeLog";
    RadioGroup chest_pain,chest_pain2,fast_bs,rest_ecg,exercise,slopee,ves,ves2,thal;
    SeekBar ages,bp,chol,heart,depression;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        ImageButton female = findViewById(R.id.female);
        female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Form.this, "Female", Toast.LENGTH_SHORT).show();
            }
        });

        ImageButton male = findViewById(R.id.male);
        male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Form.this, "Male", Toast.LENGTH_SHORT).show();
            }
        });
        chest_pain = findViewById(R.id.chest_pain);
        chest_pain.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.typical:
                        Toast.makeText(Form.this, "Typical Angina", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.atypical:
                        Toast.makeText(Form.this, "Atypical Angina", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        chest_pain2 = findViewById(R.id.chest_pain2);
        chest_pain2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch(i){
                    case R.id.non:
                        Toast.makeText(Form.this, "Non-Anginal", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.asymp:
                        Toast.makeText(Form.this, "Asymptomatic", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        ages = findViewById(R.id.age);
        ages.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int i =0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                i= progress;

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(Form.this, "Age:" +i , Toast.LENGTH_SHORT).show();

            }
        });
        bp = findViewById(R.id.bp);
        bp.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int i =0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                 i = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(Form.this, "BP:" +i , Toast.LENGTH_SHORT).show();

            }
        });
        chol = findViewById(R.id.chol);
        chol.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int i = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                i = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(Form.this, "Cholesterol:" + i, Toast.LENGTH_SHORT).show();

            }
        });
        fast_bs = findViewById(R.id.fast_bs);
        fast_bs.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.true_1:
                        Toast.makeText(Form.this, "1", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.false_0:
                        Toast.makeText(Form.this, "0", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        rest_ecg = findViewById(R.id.rest_ecg);
        rest_ecg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.ecg_0:
                        Toast.makeText(Form.this, "0", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.ecg_1:
                        Toast.makeText(Form.this, "1", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.ecg_2:
                        Toast.makeText(Form.this, "2", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        heart = findViewById(R.id.heart);
        heart.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int i =0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                i = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(Form.this, "Heart Rate:" +i , Toast.LENGTH_SHORT).show();

            }
        });
        exercise = findViewById(R.id.exercise);
        exercise.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.yes:
                        Toast.makeText(Form.this, "Yes", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.no:
                        Toast.makeText(Form.this, "No", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        depression = findViewById(R.id.depression);
        depression.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int i =0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                i = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(Form.this, "Depression Level:" +i , Toast.LENGTH_SHORT).show();

            }
        });
        slopee = findViewById(R.id.slopee);
        slopee.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.sl_1:
                        Toast.makeText(Form.this, "1", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.sl_2:
                        Toast.makeText(Form.this, "2", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.sl_3:
                        Toast.makeText(Form.this, "3", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        ves = findViewById(R.id.ves);
        ves.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.v_0:
                        Toast.makeText(Form.this, "0", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.v_1:
                        Toast.makeText(Form.this, "1", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        ves2 = findViewById(R.id.ves2);
        ves2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.v_2:
                        Toast.makeText(Form.this, "2", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.v_3:
                        Toast.makeText(Form.this, "3", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        thal = findViewById(R.id.thala);
        thal.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.normal:
                        Toast.makeText(Form.this, "Normal", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.fixed:
                        Toast.makeText(Form.this, "Fixed Defect", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.reverse:
                        Toast.makeText(Form.this, "Reversible Defect ", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
    }
}